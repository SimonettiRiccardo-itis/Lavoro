const BASE = 'https://jsonplaceholder.typicode.com';
const elenco = document.getElementById('elenco');
const messaggio = document.getElementById('messaggio');

// funzione riutilizzabile con callback (come nella teoria)
function richiediJSON(url, onSuccesso, onErrore) {
  const xhr = new XMLHttpRequest();
  xhr.onload = function () {
    if (xhr.status === 200) {
      onSuccesso(JSON.parse(xhr.responseText));
    } else {
      onErrore('Errore HTTP: ' + xhr.status);
    }
  };
  xhr.onerror = function () {
    onErrore('Errore di rete: server irraggiungibile');
  };
  xhr.ontimeout = function () {
    onErrore('Timeout della richiesta');
  };
  xhr.timeout = 5000;
  xhr.open('GET', url, true);
  xhr.send();
}

function mostraMessaggio(testo, errore) {
  messaggio.textContent = testo;
  messaggio.className = errore ? 'errore' : '';
}

function mostraUtenti(utenti) {
  elenco.textContent = '';
  if (utenti.length === 0) {
    mostraMessaggio('Nessun utente trovato', true);
    return;
  }
  mostraMessaggio('Utenti trovati: ' + utenti.length);

  utenti.forEach(function (u) {
    const card = document.createElement('div');
    card.className = 'card';

    const titolo = document.createElement('h3');
    titolo.textContent = u.name + ' (' + u.username + ')';

    const info = document.createElement('p');
    info.textContent = u.email + ' - ' + u.address.city + ' - ' + u.company.name;

    const lista = document.createElement('ul');
    const btn = document.createElement('button');
    btn.textContent = 'Vedi post';
    btn.addEventListener('click', function () { caricaPost(u.id, lista); });

    card.appendChild(titolo);
    card.appendChild(info);
    card.appendChild(btn);
    card.appendChild(lista);
    elenco.appendChild(card);
  });
}

// GET con parametro in query string: /posts?userId=...
function caricaPost(userId, lista) {
  lista.textContent = 'Caricamento...';
  richiediJSON(BASE + '/posts?userId=' + userId, function (posts) {
    lista.textContent = '';
    posts.forEach(function (p) {
      const li = document.createElement('li');
      li.textContent = p.title;
      lista.appendChild(li);
    });
  }, function (err) {
    lista.textContent = err;
  });
}

function cerca() {
  const campo = document.getElementById('campo').value;
  const valore = document.getElementById('ricerca').value.trim();
  if (valore === '') {
    mostraMessaggio('Scrivi qualcosa da cercare', true);
    return;
  }
  mostraMessaggio('Caricamento...');
  // GET con parametri in query string
  const url = BASE + '/users?' + campo + '=' + encodeURIComponent(valore);
  richiediJSON(url, mostraUtenti, function (err) {
    mostraMessaggio(err, true);
  });
}

function mostraTutti() {
  mostraMessaggio('Caricamento...');
  richiediJSON(BASE + '/users', mostraUtenti, function (err) {
    mostraMessaggio(err, true);
  });
}

document.getElementById('btnCerca').addEventListener('click', cerca);
document.getElementById('btnTutti').addEventListener('click', mostraTutti);
